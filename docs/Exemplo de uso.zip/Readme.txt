CODBAR
======
Este exemplo mostra como utilizar o codbar.exe de dentro de
uma aplica��o Delphi. 

Como programa codbar foi desenvolvido em DOS,
qualquer aplica��o em DOS poder� obter os mesmos resultados.

Esta vers�o est� dispon�vel tamb�m para qualquer plataforma que
tenha compilador 'C'.


BANCOS DISPON�VEIS
==================
-ITA�
-REAL
-BRADESCO
-BOAVISTA
-BAMERINDUS
-UNIBANCO
-BEMGE
-AMERICA DO SUL

Outros bancos podem ser produzidos mediante a documenta��o fornecida
pelo mesmo.

Qualquer d�vidas entrar em contato:

TEL:     021-509-0693
e-mail:  info@gsoft.com.br


Alexandre Crivellaro
Diretor de Projetos.